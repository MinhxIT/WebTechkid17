const express = require('express');
const bcrypt = require('bcrypt');
const AuthApi = express.Router();

const UserModel = require('../models/userModel');

AuthApi.post('/login', (req, res) => {
	const { username, password } = req.body;
	UserModel.findOne({ username })
		.then(userFound => {
			if(!userFound) res.status(404).send({ error: "User not exist!" })
			else {
				if (bcrypt.compareSync(password, userFound.password)) {
					req.session.username = userFound.username;
					req.session.role = userFound.role;
					// Dung jwt de tao 1 token tu thong tin cua nguoi dung
					res.cookie("hello", "web 177777");
					res.send("Login success");
				} else res.status(401).send({ error: "Wrong password!" });
			}
		})
		.catch(error => res.status(500).send({ error }));
});

AuthApi.get('/', (req, res) => {
	// TODO: Check user
	const { username } = req.session;
	if(username) res.send({ username })
	else res.status(401).send({ message: "Unauthenticated" });
});

module.exports = AuthApi;