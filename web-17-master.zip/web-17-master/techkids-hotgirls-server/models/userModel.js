const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
	username: { type: String, required: true, unique: true },
	password: {
		type: String,
		required: true,
		validate: {
      validator: function(v) {
				if(v.length < 10) return false
				else return true;
				// return v.length < 10;
      },
      message: props => `Password is too short!`
    },
	},
	role: {
		type: String,
		default: 'user',
		required: true,
		enum: ['user', 'admin']
	},
	avatar: { type: String, required: true }
});

UserSchema.pre("save", function(next) {
	const { password } = this;
	if(this.isModified("password")) {
		const salt = bcrypt.genSaltSync(12);
		this.password = bcrypt.hashSync(password, salt);
	}
	next();
});

module.exports = mongoose.model("user", UserSchema);