const isAdmin = (req, res, next) => {
	// only admin
	const { username, role } = req.session;
	if(username && role && role === "admin") {
		next();
	} else {
		res.status(401).send({ message: "Unauthorized" });
	}
}

module.exports = { isAdmin };