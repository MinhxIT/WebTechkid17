import React, { Component } from 'react';
import axios from 'axios';

class CreateGame extends Component {
	state = {
		players: []
	}

	handleSubmit = (event) => {
		event.preventDefault();
		const { players } = this.state;
		axios({
			url: "http://10.10.0.248:6969/api/game",
			method: "POST",
			data: {
				players,
				scores: []
			}
		}).then((data) => {
			console.log(data);
		}).catch((error) => {
			console.log(error);
		});
	}

	handleChange = (event) => {
		const { name, value } = event.target;
		const { players } = this.state;
		players[name] = value;
		this.setState({ players });
	}
	
	render() {
		return (
			<div className="mt-4">
				<form onSubmit={this.handleSubmit}>
					<div className="form-group">
						<input onChange={this.handleChange} className="form-control" placeholder="Player 1" name="0" type="text" />
					</div>
					<div className="form-group">
						<input onChange={this.handleChange} className="form-control" placeholder="Player 2" name="1" type="text" />
					</div>
					<div className="form-group">
						<input onChange={this.handleChange} className="form-control" placeholder="Player 3" name="2" type="text" />
					</div>
					<div className="form-group">
						<input onChange={this.handleChange} className="form-control" placeholder="Player 4" name="3" type="text" />
					</div>
					<button type="submit" className="btn btn-danger">Create game</button>
				</form>
			</div>
		);
	}
}

export default CreateGame;