import React from 'react'

export default function Header() {
	return (
		<header className="logo" style={{
			borderBottom: '1px solid #cecece'
		}}>
			<a href="/">Score Keeper</a>
		</header>
	)
}
