import React from 'react';

export default function AddNum(props) {
  return (
		<button
			type="button"
			onClick={props.addNum}
			className="btn btn-primary"
			href="https://reactjs.org"
			target="_blank"
			rel="noopener noreferrer"
		>
			Add 1
		</button>
	);
}
