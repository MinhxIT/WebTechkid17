import React from 'react'

export default function Count(props) {
	return (
		<div>
			{props.count}
		</div>
	)
}
